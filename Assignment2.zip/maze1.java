import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class maze1 {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner sc = new Scanner(new File("maze1.txt"));

        int n, m;

        n = sc.nextInt();
        m = sc.nextInt();

        int[][] maze = new int[n][m];
        int[][] path = new int[n][m];
        int[][] dist = new int[n][m];

        for(int i = 0 ; i < n ; i++) {
            for(int j = 0 ; j < m ; j++) {
                maze[i][j] = sc.nextInt();
                dist[i][j] = 0;
            }
        }

        int sx, sy;

        sx = sc.nextInt();
        sy = sc.nextInt();

        Coordinate start = new Coordinate(sx, sy);

        myStack s = new myStack(n*m);

        int[] dx = {0, 1, 0, -1};
        int[] dy = {-1, 0, 1, 0};
        Coordinate c, t;
        int shortest = 2147483647;

        Coordinate end = new Coordinate(0, 0);

        s.push(start);
        dist[start.getRow()][start.getCol()] = 1;

        while(!s.isEmpty()) {
            c = s.pop();

            if(c.getRow() == 0 || c.getRow() == n-1 || c.getCol() ==0 || c.getCol() == m-1) {
                if(c.getRow() != start.getRow() && c.getCol() != start.getCol()) {
                    if(dist[c.getRow()][c.getCol()] < shortest) {
                        shortest = dist[c.getRow()][c.getCol()];
                        end = c;
                    }
                }
            }

            for(int i = 0 ; i < 4 ; i++) {
                t = new Coordinate(c.getRow() + dx[i], c.getCol() + dy[i]);
                if(t.getRow() >= 0 && t.getRow() < n && t.getCol() >=0 && t.getCol() < m) {
                    if(maze[t.getRow()][t.getCol()] == 1 && (dist[t.getRow()][t.getCol()] > dist[c.getRow()][c.getCol()] + 1 || dist[t.getRow()][t.getCol()] == 0)) {
                        s.push(t);
                        path[t.getRow()][t.getCol()] = i;
                        dist[t.getRow()][t.getCol()] = dist[c.getRow()][c.getCol()] + 1;
                    }
                }
            }
        }

        int size = dist[end.getRow()][end.getCol()];
        myStack p = new myStack(size);

        t = end;
        int x, y;

        for(int i = 0 ; i < size - 1 ; i++) {
            x = t.getRow();
            y = t.getCol();
            p.push(t);
            t = new Coordinate(x - dx[path[x][y]], y - dy[path[x][y]]);
        }

        System.out.print(start);

        while(!p.isEmpty()) {
            System.out.print(", " + p.pop());
        }
    }
}