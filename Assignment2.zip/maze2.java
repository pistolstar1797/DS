import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class maze2 {
    static int n, m;
    static int[][] maze;
    static int[][] path;
    static int[][] dist;
    static int sx, sy;
    static Coordinate start;
    static Coordinate c, t;
    static myStack s;
    static int longest = 0;
    static Coordinate[] temp;
    static Coordinate[] ans;

    public static void main(String[] args) throws FileNotFoundException {
        Scanner sc = new Scanner(new File("maze2.txt"));

        n = sc.nextInt();
        m = sc.nextInt();

        maze = new int[n][m];
        path = new int[n][m];
        dist = new int[n][m];
        s = new myStack(n*m);
        temp = new Coordinate[n*m+10];
        ans = new Coordinate[n*m+10];

        for(int i = 0 ; i < n ; i++) {
            for(int j = 0 ; j < m ; j++) {
                maze[i][j] = sc.nextInt();
                dist[i][j] = 0;
            }
        }


        sx = sc.nextInt();
        sy = sc.nextInt();

        start = new Coordinate(sx, sy);

        dfs(start, 1);

        for(int i = 1 ; i < longest ; i++) {
            System.out.print(ans[i] + ", ");
        }

        System.out.print(ans[longest]);
    }

    static void dfs(Coordinate c, int size) {
        int x = c.getRow();
        int y = c.getCol();

        temp[size] = c;

        if(x < 0 || x >= n || y < 0 || y >= m) {
            return;
        }

        if(maze[x][y] != 1) {
            return;
        }

        maze[x][y] = 2;

        if(dist[x][y] < size) {
            dist[x][y] = size;
        }

        if(x == 0 || x == n-1 || y == 0 || y == m-1) {
            if(x != sx || y != sy) {
                if(longest < size) {
                    longest = size;
                    System.arraycopy(temp, 0, ans, 0, temp.length);
                }
                maze[x][y] = 1;
                return;
            }
        }

        t = new Coordinate(x - 1, y);
        dfs(t, size + 1);

        t = new Coordinate(x, y + 1);
        dfs(t, size + 1);

        t = new Coordinate(x + 1, y);
        dfs(t, size + 1);

        t = new Coordinate(x, y - 1);
        dfs(t, size + 1);

        maze[x][y] = 1;
    }
}