import java.io.*;
import java.util.HashMap;
import java.util.Scanner;

public class array {
    public static void main (String[] args) throws FileNotFoundException {
        Scanner sc = new Scanner(new File("array.txt"));
        HashMap<Integer, Integer> a = new HashMap<Integer, Integer>();

        a.put(0, sc.nextInt());

        while(sc.hasNextLine()) {
            a.put(a.size(), a.get(a.size() - 1) + sc.nextInt());
        }

        for(int i = 0 ; i < a.size() ; i++) {
            if(a.get(i) == 0) {
                System.out.println("Subarray found from Index 0 to " + i);
            }

            for(int j = 0 ; j < i ; j++) {
                if(a.get(j) - a.get(i) == 0) {
                    System.out.println("Subarray found from Index " + (j + 1) + " to " + i);
                }
            }
        }
    }
}
