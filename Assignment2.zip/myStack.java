public class myStack {
    int top;
    int size;
    Coordinate[] stack;

    public myStack(int size) {
        this.size = 2*size;
        stack = new Coordinate[this.size];
        top = -1;
    }

    public boolean isEmpty() {
        if(top == -1) {
            return true;
        }
        else {
            return false;
        }
    }

    public void push(Coordinate c) {
        top++;
        stack[top] = c;
    }

    public Coordinate peek() {
        return stack[top];
    }

    public Coordinate pop() {
        top--;
        return stack[top + 1];
    }
}
