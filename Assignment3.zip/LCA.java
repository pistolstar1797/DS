// 2017-12751 Donghak Lee

import java.util.ArrayList;

class Node {
    int data;
    Node left, right;

    Node (int d) {
        this.data = d;
        left = right;
    }
}

public class LCA {
    static ArrayList<Node> p1 = new ArrayList<>();
    static ArrayList<Node> p2 = new ArrayList<>();

    public static void main(String[] args) {
        Node root = new Node(1);
        root.left = new Node(2);
        root.right = new Node(3);
        root.left.left = new Node(4);
        root.left.right = new Node(5);
        root.right.right = new Node(6);
        root.right.right.left = new Node(7);
        root.left.right.left = new Node(8);
        root.left.right.right = new Node(9);
        Node n1 = new Node(8);
        Node n2 = new Node(9);

        printCommonPath(root, n1, n2);
    }

    static void printCommonPath(Node root, Node n1, Node n2) {
        if(findPath1(root, n1) && findPath2(root, n2)) {
            String ans = "";
            ans += p1.get(0).data;

            for (int i = 1; i < Integer.min(p1.size(), p2.size()); i++) {
                if (p1.get(i).data == p2.get(i).data) {
                    ans += "->";
                    ans += p1.get(i).data;
                } else {
                    break;
                }
            }

            System.out.println(ans);
        }
        else {
            System.out.println("No Common Path");
        }
    }

    static boolean findPath1(Node root, Node n) {
        if(root == null) {
            return false;
        }

        p1.add(root);

        if(root.data == n.data) {
            return true;
        }

        if(findPath1(root.left, n) || findPath1(root.right, n)) {
            return true;
        }

        p1.remove(p1.size() - 1);

        return false;
    }

    static boolean findPath2(Node root, Node n) {
        if(root == null) {
            return false;
        }

        p2.add(root);

        if(root.data == n.data) {
            return true;
        }

        if(findPath2(root.left, n) || findPath2(root.right, n)) {
            return true;
        }

        p2.remove(p2.size() - 1);

        return false;
    }
}
