//2017-12751 Donghak Lee

import java.util.LinkedList;
import java.util.Queue;

class Node {
    char data;
    Node left, right;

    Node (char c) {
        this.data = c;
        left = right;
    }
}

public class MyTree01 {
    Node head;
    String preorder;
    String ans;
    int build;

    MyTree01 (String input) {
        this.preorder = input;
        this.build = 0;
        this.head = preorder();
    }

    Node preorder() {
        char c = preorder.charAt(build);
        Node temp = new Node(c);
        build++;

        if(c == '+' || c == '-' || c == '*' || c == '/') {
            temp.left = preorder();
            temp.right = preorder();
        }

        return temp;
    }

    String postorder() {
        ans = "";
        po(head);

        return ans;
    }

    void po (Node t) {
        if(t == null) {
            return;
        }

        po(t.left);
        po(t.right);
        ans += t.data;
    }

    String inorder() {
        ans = "";
        io(head);

        return ans;
    }

    void io (Node t) {
        if(t == null) {
            return;
        }

        char c = t.data;

        if(c == '+' || c == '-' || c == '*' || c == '/') {
            ans += "(";
        }
        io(t.left);
        ans += t.data;
        io(t.right);
        if(c == '+' || c == '-' || c == '*' || c == '/') {
            ans += ")";
        }
    }

    String levelorder() {
        ans = "";
        Node temp;

        Queue<Node> q = new LinkedList<>();
        q.offer(head);

        while(!q.isEmpty()) {
            temp = q.poll();

            ans += temp.data;

            if(temp.left != null) {
                q.offer(temp.left);
            }
            if(temp.right != null) {
                q.offer(temp.right);
            }
        }

        return ans;
    }
}
