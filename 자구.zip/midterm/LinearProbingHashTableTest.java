/** Class LinearProbingHashTableTest **/
public class LinearProbingHashTableTest
{
    public static void main(String[] args)
    {


    }
}
