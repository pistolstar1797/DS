import java.util.Scanner;

public class myDFS {
    public static void main (String[] args) {
        Scanner sc = new Scanner(System.in);
        String temp;
        int[][] a;
        int n;

        temp = sc.nextLine();
        n = temp.length();
        a = new int[n+1][n+1];

        for(int i = 1 ; i <= n ; i++) {
            a[1][i] = (int)temp.charAt(i-1) - '0';
        }

        for(int i = 2 ; i <= n ; i++) {
            temp = sc.nextLine();

            for(int j = 1 ; j <= n ; j++) {
                a[i][j] = (int)temp.charAt(j-1) - '0';
            }
        }

        DFS(a, n);
    }

    public static void DFS(int[][] a, int size) {
        boolean[] visit = new boolean[size + 1];
        int cnt = 0;

        DFSutil(a, size, visit, size);

        System.out.print("The source node " + size + " is connected to: ");

        for(int i = 1 ; i <= size ; i++) {
            if(visit[i]) {
                System.out.print(i + " ");
                cnt++;
            }
        }

        System.out.println();

        if(cnt == size) {
            System.out.println("The Graph is Connected");
        }
        else {
            System.out.println("The Graph is Unconnected");
        }
    }

    public static void DFSutil (int[][] a, int size, boolean[] visit, int root) {
        visit[root] = true;

        for(int i = 1 ; i <= size ; i++) {
            if(a[root][i] == 1 && !visit[i]) {
                DFSutil(a, size, visit, i);
            }
        }
    }
}
