import java.util.PriorityQueue;
import java.util.Scanner;

class Node implements Comparable <Node> {
    private int name;
    private int td;

    public Node (int n, int d) {
        this.name = n;
        this.td = d;
    }

    public int getN() {
        return name;
    }

    public int getD() {
        return td;
    }

    public int compareTo (Node target) {
        if(this.getD() > target.getD()) {
            return 1;
        }
        else if (this.getD() < target.getD()) {
            return -1;
        }
        return 0;
    }
}

public class myDij {
    public static void main (String[] args) {
        Scanner sc = new Scanner(System.in);
        String temp;
        int[][] a;
        int n, s;

        temp = sc.nextLine();
        n = temp.length();
        a = new int[n+1][n+1];

        for(int i = 1 ; i <= n ; i++) {
            a[1][i] = (int)temp.charAt(i-1) - '0';
        }

        for(int i = 2 ; i <= n ; i++) {
            temp = sc.nextLine();

            for(int j = 1 ; j <= n ; j++) {
                a[i][j] = (int)temp.charAt(j-1) - '0';
            }
        }

        s = sc.nextInt();

        Dij(a, n, s);
    }

    public static void Dij (int[][] a, int n, int s) {
        boolean[] visit = new boolean[n + 1];
        int[] dist = new int[n + 1];
        PriorityQueue<Node> Q = new PriorityQueue<>();
        Node temp, temp2;

        for(int i = 1 ; i <= n ; i++){
            dist[i] = Integer.MAX_VALUE;
        }

        dist[s] = 0;
        visit[s] = true;

        for(int i = 1 ; i <= n ; i++){
            if(!visit[i] && a[s][i] !=0){
                dist[i] = a[s][i];
                temp = new Node(i, dist[i]);
                Q.offer(temp);
            }
        }


        while (!Q.isEmpty()) {
            temp = Q.poll();

            int min_index = temp.getN();

            visit[min_index] = true;

            for(int i = 1 ; i <= n ; i++){
                if(!visit[i] && a[min_index][i] != 0){
                    if(dist[i] > dist[min_index] + a[min_index][i]){
                        dist[i] = dist[min_index] + a[min_index][i];
                        temp2 = new Node(i, dist[i]);
                        Q.offer(temp2);
                    }
                }
            }
        }

        System.out.println("The Shorted Path to all nodes are");
        for(int i = 1 ; i <= n ; i++) {
            if (dist[i] == Integer.MAX_VALUE) {
                System.out.println("No Path from " + s + " to " + i);
            } else {
                System.out.println(s + " to " + i + " is " + dist[i]);
            }
        }
    }
}